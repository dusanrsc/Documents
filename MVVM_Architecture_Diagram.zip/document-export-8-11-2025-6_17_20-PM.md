# MVVM Architecture Diagram



